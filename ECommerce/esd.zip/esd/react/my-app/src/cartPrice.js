import './App.css';
const CartPrice = () => {
    return(

        <>
        <tr>
                <td>Subtotal</td>
                <td>Rs2400</td>
        </tr>
            
        </>
    )
}

export default CartPrice;